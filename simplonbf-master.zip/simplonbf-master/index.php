<?php
header('location:public');
?>
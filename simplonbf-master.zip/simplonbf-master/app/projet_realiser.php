<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class projet_realiser extends Model
{
    protected $guarded=[];
}

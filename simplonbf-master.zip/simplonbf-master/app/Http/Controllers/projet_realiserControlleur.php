<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class projet_realiserControlleur extends Controller
{
    function store(){

    }
}

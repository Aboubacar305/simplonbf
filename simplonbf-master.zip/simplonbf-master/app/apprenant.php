<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class apprenant extends Model
{
    protected $guarded=[];


}
